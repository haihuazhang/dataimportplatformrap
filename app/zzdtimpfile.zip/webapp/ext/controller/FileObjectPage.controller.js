sap.ui.define(['sap/ui/core/mvc/ControllerExtension'], function (ControllerExtension) {
	'use strict';

	return ControllerExtension.extend('zzdtimpfile.ext.controller.FileObjectPage', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf zzdtimpfile.ext.controller.FileObjectPage
			 */
			// onInit: function () {
			// 	// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
			// 	var oModel = this.base.getExtensionAPI().getModel();


			// 	//Get Geo Map Controller. Full id: "zgeomovingobjectlistv4::MovingObjectObjectPage--fe::CustomSubSection::Geomap--GeoMapControl"
			// 	// var oGeomapController = oExtensionAPI.byId("fe::CustomSubSection::Geomap--GeoMapControl");

			// },
			// onAfterRendering: function (oObjectPageEvent) {
			// 	var oObjectPageController = this;
			// 	var oExtensionAPI = oObjectPageController.base.getExtensionAPI();
			// 	var oLogMessagesControlContainer = oExtensionAPI.byId("fe::CustomSubSection::myCustomSection--LogMessagesControlContainer");
			// 	var oModel = this.base.getExtensionAPI().getModel();

			// 	var oNote = oModel.bindProperty("/SalesOrderList('0500000000')/Note");
			// }
			routing: {

				onAfterBinding: async function (oBindingContext) {
					const
						oExtensionAPI = this.base.getExtensionAPI();
					// Request OData function with current CustomerID
					// const oCurrentContextObject = await oBindingContext.requestObject(oBindingContext.getPath() + '/LogHandle');
					const sLogHandle = await oBindingContext.requestProperty('LogHandle');
					var oLogMessagesControlContainer = oExtensionAPI.byId("fe::CustomSubSection::myCustomSection--LogMessagesControlContainer");

					this.base.getAppComponent().createComponent({
						usage: "ApplicationLogs",
						id: "LogMessagesControlComponent",
						settings: {
							"persistencyKey": "MY_LOG_DISPLAY_VIEW",
							"showHeader": false,
							"showFilterBar": false,
							"showAsTree": false,
							// "showContextFields": true
						}
					}).then(function (oComp) {
						// that.byId("LogMessagesControlContainer").setComponent(oComp);
						oLogMessagesControlContainer.setComponent(oComp);
						oComp.setLogHandle(sLogHandle);
						oComp.refresh();
					});
				}

			}

		}
	});
});
